#!/bin/bash
#  Name:
#     uploadSample.sh
#
#  Description:
#     Upload example syslog or alert log files to Log Analytics Cloud Service 
#
#  Dependencies:
#     - curl with TLS 1.2 support
#     - Property file <SCRIPT_HOME>/config/upload.properties
#

#   MODIFIED   (MM/DD/YY) COMMENTS
#   lnhan       03/16/18  Modify grep and sed commands for running on Solaris  
#   lnhan       11/20/17  Update to cover V4 tenant type
#   lnhan       08/25/17  Creation

# Function usage 
usage() {
cat <<EOF
Usage: $SCRIPT_NAME alerlog|syslog 
   alertlog: sample database alert log 
   syslog:   sample syslog

EOF
} # End of function usage
 
# --------------------------------------------------------------------
# Main
# --------------------------------------------------------------------

SCRIPT_NAME=$(basename $0)

SCRIPT_HOME=$(cd $(dirname $0); pwd)

if [ -z "$1" ];
then
   usage
   exit 1
fi

case "$1" in
   alertlog)
      LOG_TYPE=db_alert_log
      ;;
   syslog)
      LOG_TYPE=os_syslog
      ;;
   *)
      usage
      exit 1
      ;;
esac

# Preset parameters
TIMEZONE=PST
LOG_YEAR=2017
# End of preset parameters

TIMESTAMP=`date +"%Y-%m-%d_%H:%M:%S"`

if [ "$LOG_TYPE" = "db_alert_log" ]; then
   LOG_FILE="$SCRIPT_HOME/logs/alertlog.zip"
   ENTITY_NAME="demo_db_instance"
   ENTITY_TYPE="Oracle%20Database%20Instance"
   LOG_SOURCE="Database%20Alert%20Logs"
   UPLOAD_NAME="alertlog.${TIMESTAMP}" 
fi
if [ "$LOG_TYPE" = "os_syslog" ]; then
   LOG_FILE="$SCRIPT_HOME/logs/messages.zip"
   ENTITY_NAME=demo_host
   ENTITY_TYPE="Host%20(Linux)"
   LOG_SOURCE=Linux%20Syslog%20Logs
   UPLOAD_NAME="syslog.${TIMESTAMP}" 
fi

which curl &>/dev/null
if [ $? -ne 0 ]; then
   echo "Please make sure that curl executable exists and its location is listed in the environment variable PATH" 
   exit 1
fi

curl --help | grep tlsv1.2 >/dev/null
if [ $? -ne 0 ]; then
   echo "ERROR: Make sure that your curl executable supports TLS 1.2"
   exit 1
fi

PROP_FILE="${SCRIPT_HOME}/config/upload.properties"

if [ ! -f "$PROP_FILE" ]; then
   echo "ERROR: Properties file $PROP_FILE does not exist or inaccessible"
   exit 1
fi


# Check that required properties are set in the property file.
#
UPLOAD_ROOT=`grep "^UPLOAD_ROOT" ${PROP_FILE}| awk -F= '{print $2}'`
if [ -z "$UPLOAD_ROOT" ]; then
   echo "ERROR: Missing value for UPLOAD_ROOT in file $PROP_FILE" 
   MANDATORY_PROPS_SET=NO
fi
#
IDENTITY_DOMAIN=`grep "^IDENTITY_DOMAIN" ${PROP_FILE}| awk -F= '{print $2}'`
if [ -z "$IDENTITY_DOMAIN" ]; then
   echo "ERROR: Missing value for IDENTITY_DOMAIN in file $PROP_FILE" 
   MANDATORY_PROPS_SET=NO
fi
#
USER=`grep "^USERNAME" ${PROP_FILE}| awk -F= '{print $2}'`
if [ -z "$USER" ]; then
   echo "ERROR: Missing value for USERNAME in file $PROP_FILE" 
   MANDATORY_PROPS_SET=NO   
fi
#
if [ "$MANDATORY_PROPS_SET" = "NO" ]; then
   exit 1
fi
 
PASS=`grep "^PASSWORD" ${PROP_FILE}| awk -F= '{print $2}'`

if [ -z "$PASS"  ]; then
   CREDENTIAL="${USER}"
else
   CREDENTIAL="${USER}:${PASS}" 
fi

# Remove any trailing slashes in UPLOAD_ROOT
UPLOAD_ROOT=`echo "$UPLOAD_ROOT" | sed -e "s,/*$,,"`
# 

if [[ "$UPLOAD_ROOT" == https://* ]]; then
   EDGE_END_POINT=${UPLOAD_ROOT}
else
   # Prefix URL with "https://" as it is not included in the value of UPLOAD_ROOT
   EDGE_END_POINT=https://${UPLOAD_ROOT}
fi
# 

HTTPS_PROXY=`grep "^HTTPS_PROXY" ${PROP_FILE}| awk -F= '{print $2}'`

if [ ! -z "$HTTPS_PROXY" ]; then
   export HTTPS_PROXY 
fi

DATA="data=@${LOG_FILE}"

curl -v -k  --tlsv1.2 \
 -u ${CREDENTIAL} \
 -X POST -H "X-USER-IDENTITY-DOMAIN-NAME:$IDENTITY_DOMAIN" \
 -F ${DATA} \
 "${EDGE_END_POINT}/serviceapi/logan.uploads?uploadName=${UPLOAD_NAME}&entityName=${ENTITY_NAME}&entityType=${ENTITY_TYPE}&timezone=${TIMEZONE}&dateYear=${LOG_YEAR}&logSourceName=${LOG_SOURCE}"

if [ "$?" -ne 0 ]; then
   echo "ERROR: $SCRIPT_NAME encountered an error while uploading $1. Please check the script's output." 
   exit 1
else
   echo ""
   echo "Upload name: $UPLOAD_NAME"
fi
